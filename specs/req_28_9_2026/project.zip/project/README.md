# Chuyển đổi số thanh toán số cấp thôn

Hệ thống ghi nhận và báo cáo toàn bộ dòng tiền trong thôn — mua bán, quỹ chung, công đức — do SKHG phát triển. Hệ thống không giữ tiền: tiền đi thẳng vào tài khoản người nhận, giao dịch được ghi nhận tự động qua kết nối ngân hàng / đối tác.

Trạng thái: MVP, đang ở giai đoạn tài liệu. Chưa có mã nguồn.

## Tài liệu

- [Product Brief](docs/product-brief.md)
- [Requirements (SRS)](docs/requirements.md)
- [Architecture](docs/architecture.md)
- [ADR](docs/adr/)

## Cài đặt và chạy

`[NEED DECISION]` — bổ sung khi chốt stack công nghệ.
