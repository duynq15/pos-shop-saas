# ADR-XXXX: <Tiêu đề quyết định>

- **Trạng thái:** Proposed | Accepted | Superseded by ADR-XXXX
- **Ngày:** YYYY-MM-DD
- **Liên quan:** <ID trong requirements.md>

## Bối cảnh

<Vấn đề cần quyết định, các ràng buộc, các phương án đã xét.>

## Quyết định

<Chọn gì.>

## Hệ quả

<Được gì, phải chấp nhận gì, điều kiện đi kèm.>
