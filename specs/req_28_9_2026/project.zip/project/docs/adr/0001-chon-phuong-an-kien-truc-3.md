# ADR-0001: Chọn Phương án kiến trúc 3 — ứng dụng độc lập, ghi nhận tự động qua kết nối ngân hàng

- **Trạng thái:** Accepted
- **Ngày:** 2026-09-28
- **Liên quan:** FR-05, FR-06, FR-07, US-06, ERR-01, ERR-02, ERR-03, ERR-10, SEC-01, SEC-06

## Bối cảnh

SRS để mở FR-07: giao dịch được đưa vào hệ thống tự động (A) hay xác nhận thủ công (B), và NFR-01: hệ thống độc lập hay nằm trong sản phẩm SKHG sẵn có. `docs/architecture.md` đưa ra 3 phương án:

- PA1 — ứng dụng độc lập, ghi nhận thủ công
- PA2 — module trong Làng Văn Hiến, thủ công trước
- PA3 — ứng dụng độc lập, ghi nhận tự động qua kết nối ngân hàng / đối tác

## Quyết định

Chọn **PA3**. FR-07 chốt phương án A (ghi nhận tự động).

## Hệ quả

Tích cực:

- Đạt đúng US-06 "tự động"; số tiền lấy từ ngân hàng nên tin cậy.
- Người bán không phải thao tác xác nhận; giảm ERR-01, ERR-02 nhờ đối soát tự động.

Phải chấp nhận:

- Phụ thuộc đối tác ngân hàng / dịch vụ đồng bộ giao dịch (hợp đồng, phí, thay đổi API).
- Chi phí và độ phức tạp cao nhất trong ba phương án; thời gian ra MVP dài nhất.
- ERR-10 (gián đoạn kết nối) và ERR-03 (không khớp mã) trở thành luồng xử lý bắt buộc.

Điều kiện đi kèm, phải xong trước khi ký hợp đồng đối tác:

- [ ] Chốt ngân hàng / đối tác cụ thể [NEED DECISION]
- [ ] Xác minh pháp lý về quyền đọc giao dịch tài khoản cá nhân và sự đồng ý của người dùng (SEC-06)
- [ ] Làm rõ trường hợp người bán dùng nhiều ngân hàng khác nhau
