# CLAUDE.md — Hướng dẫn cho Claude

Tài liệu này cho Claude biết project là gì, đọc gì trước, và những quy tắc không được vi phạm khi làm việc trong repo.

## Project

Hệ thống chuyển đổi số thanh toán số cấp thôn do SKHG phát triển. Tư duy nền: coi thôn như một doanh nghiệp lớn; mọi giao dịch mua bán của người dân, thu chi quỹ chung và công đức đều được ghi nhận vào một hệ thống chung và tự sinh báo cáo cho từng bên (người bán, thủ quỹ, ban lãnh đạo thôn, nhà cung cấp, người dân, SKHG).

Giai đoạn hiện tại: MVP, thí điểm tại một thôn.

## Đọc trước khi làm bất cứ việc gì

| Tài liệu | Vai trò |
| --- | --- |
| `docs/product-brief.md` | Vấn đề, người dùng, phạm vi MVP, rủi ro |
| `docs/requirements.md` | SRS — nguồn chuẩn cho FR, NFR, US, AC, BR, ERR, SEC |
| `docs/architecture.md` | 3 phương án kiến trúc và quyết định đã chọn |
| `docs/adr/` | Các quyết định kiến trúc đã chốt (ADR) |

Khi các tài liệu mâu thuẫn: ADR mới nhất > `requirements.md` > `architecture.md` > `product-brief.md`.

## Quyết định đã chốt

- **Hệ thống không giữ tiền** (BR-02, FR-05, SEC-01). Tiền đi thẳng từ tài khoản người trả sang tài khoản người nhận. Không viết code khởi tạo lệnh chuyển tiền, không xây ví, không làm trung gian thanh toán.
- **Kiến trúc: Phương án 3** — ứng dụng độc lập, ghi nhận giao dịch tự động qua kết nối ngân hàng / đối tác (FR-07 = phương án A). Xem `docs/adr/0001-chon-phuong-an-kien-truc-3.md`.

## Quy tắc bắt buộc

1. **Không tự thêm requirement.** Mọi code phải truy vết được về một ID trong `docs/requirements.md`. Việc chưa có ID thì hỏi, không tự làm.
2. **Không tự bịa thông tin.** Điểm chưa xác định ghi `[NEED DECISION]`, không đặt giá trị giả định (ngưỡng, thời gian, phí, tên đối tác, stack).
3. **Ghi ID trong code và test**: tên test, comment hoặc commit message tham chiếu FR-xx / AC-xx-x / ERR-xx / SEC-xx tương ứng.
4. **Giao dịch không bao giờ bị xóa** (BR-04). Sửa sai bằng bút toán điều chỉnh, có lưu lịch sử.
5. **Mỗi giao dịch thuộc đúng một loại**: mua bán, quỹ chung, công đức (BR-01). Giao dịch không xác định được loại hoặc quỹ thì không tự gán (ERR-03).
6. **Phân quyền theo vai trò** (BR-08, SEC-02): người bán chỉ thấy dữ liệu của mình, thủ quỹ chỉ thấy quỹ được giao.
7. **Webhook từ ngân hàng / đối tác là dữ liệu không tin cậy**: phải xác thực nguồn, chống giả mạo, không log khóa / token API.
8. **Chỉ lấy dữ liệu tài khoản cần cho FR-06.** Mọi thứ liên quan quyền đọc giao dịch tài khoản cá nhân phải chờ xác minh pháp lý (SEC-06).
9. Quyết định kiến trúc mới → viết ADR mới trong `docs/adr/`, không sửa lặng lẽ ADR cũ.

## Còn mở — không tự quyết

- Đối tác ngân hàng / dịch vụ đồng bộ giao dịch (FR-07)
- Stack công nghệ (framework, CSDL, hosting) — chưa có trong tài liệu
- Nền tảng: app di động, web hay cả hai (NFR-01)
- Các BR đang `[NEED DECISION]`: BR-05, 06, 07, 09, 11, 12, 13
- Xác minh pháp lý: hoạt động thanh toán, thuế / hóa đơn, bảo vệ dữ liệu cá nhân

Danh sách đầy đủ: mục 8 của `docs/requirements.md`.

## Cấu trúc repo

```
project/
├── CLAUDE.md          # Tài liệu này
├── README.md
├── docs/
│   ├── product-brief.md
│   ├── requirements.md
│   ├── architecture.md
│   └── adr/           # Architecture Decision Records
├── src/               # Mã nguồn — chưa có, chờ chốt stack
└── tests/             # Test — đặt tên theo AC / ERR
```

## Lệnh build, chạy, test

`[NEED DECISION]` — sẽ bổ sung khi chốt stack.

## Cách viết

- Tài liệu và giao tiếp bằng tiếng Việt, ngắn gọn, tự nhiên.
- Giữ nguyên hệ ID hiện có; ID mới đánh tiếp số, không dùng lại ID đã xóa.
